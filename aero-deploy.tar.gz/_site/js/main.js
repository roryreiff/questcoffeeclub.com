$('#reviews-wall').masonry({
    // options
    itemSelector: '.box-review',
    gutter: 48
});